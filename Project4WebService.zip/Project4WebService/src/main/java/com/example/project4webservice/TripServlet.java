package com.example.project4webservice;
import java.io.*;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * Servlet class to handle get requests and redirect them to the Model class for executing logic.
 */

@WebServlet(name = "tripServlet", urlPatterns = {"/getTripResults", "/getDashboard"})
public class TripServlet extends HttpServlet {
    TripModel tm; // declare an instance of the TripModel class

    // initialize the instance of TripModel
    public void init() {
        this.tm = new TripModel();
    }

    // handle GET requests
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String path = request.getServletPath(); // get the current servlet path

        if (path.equals("/getTripResults")) { // if the path is "/getTripResults"
            String departure_airport = request.getParameter("from"); // get the "from" parameter from the request
            String destination_airport = request.getParameter("to"); // get the "to" parameter from the request
            // validate the airport codes
            if (!validate(departure_airport.trim()) || !validate(destination_airport.trim())) {
                System.out.println("Invalid inputs from the app.");
                return;
            }
            // get the phone information from the request
            String phoneInfo = request.getParameter("phone");

            // get the trip information and return it as a JSON response
            String jsonResponse = tm.handleRequest(departure_airport, destination_airport, phoneInfo);
            // check for errors
            if (jsonResponse == null) {
                System.out.println("Error encountered in getting information.");
                return;
            }
            // Set response content type to JSON
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            // Write JSON response to the response body
            response.getWriter().write(jsonResponse);
        } else { //path to display the dashboard
            // get logs and analytics for the dashboard
            List<Log> logs = tm.getDashboardLogs();
            List<String> analytics = tm.getDashboardAnalytics();
            // set the logs and analytics as attributes of the reques
            request.setAttribute("logs", logs);
            request.setAttribute("analytics", analytics);
            // forward the request to the dashboard.jsp page
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            view.forward(request, response);
        }
    }

    //method to validate airport code
    private boolean validate(String code) {
        //check if length is 3
        if (code.length() != 3) {
            return false;
        }
        //check if each character is a letter
        for (int i = 0; i < 3; i++) {
            if (!Character.isLetter(code.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public void destroy() {
    }
}