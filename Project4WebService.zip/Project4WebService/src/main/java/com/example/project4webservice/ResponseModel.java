package com.example.project4webservice;
/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * Model class to define structure of the response to be sent to the android app,
 * with only the required information.
 */
public class ResponseModel {
    String departure_airport;
    String destination_airport;
    double distance_value;
    double carbon_kg;
    public ResponseModel(String departure_airport, String destination_airport, double distance_value, double carbon_kg) {
        this.departure_airport = departure_airport;
        this.destination_airport = destination_airport;
        this.distance_value = distance_value;
        this.carbon_kg = carbon_kg;
    }
}
