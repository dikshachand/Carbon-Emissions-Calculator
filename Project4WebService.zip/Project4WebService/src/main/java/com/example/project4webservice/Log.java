package com.example.project4webservice;
/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * Class to store structure of a Log, with required fields to send to the mongo database.
 */
public class Log {
    String departure_airport;
    String destination_airport;
    double distance_value;
    String estimated_at;
    double carbon_kg;
    double carbon_lb;
    String phone;

    public double getCarbon_kg() {
        return carbon_kg;
    }

    public double getCarbon_lb() {
        return carbon_lb;
    }

    public double getDistance_value() {
        return distance_value;
    }

    public String getDeparture_airport() {
        return departure_airport;
    }

    public String getDestination_airport() {
        return destination_airport;
    }

    public String getEstimated_at() {
        return estimated_at;
    }
    public String getPhone() { return phone; }
}
