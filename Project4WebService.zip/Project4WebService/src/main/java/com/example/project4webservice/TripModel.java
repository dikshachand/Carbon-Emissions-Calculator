package com.example.project4webservice;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import com.google.gson.JsonSyntaxException;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import org.bson.Document;
import org.json.JSONObject;

/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * TripModel class handles all the business logic of the application. The functions are called
 * by the servlet class, it performs appropriate execution and returns data.
 */
public class TripModel {
    //mongo collection data structure to store inserted and retrieved documents
    MongoCollection<Document> collection;
    //List of class Log for logging of information to display on the dashboard
    List<Log> logs;
    public TripModel() {
        //Making a connection to the mongoDB server and retrieving the database and collection
        ConnectionString connectionString = new ConnectionString("mongodb+srv://dikshachand:whateverworks@cluster0.6spuc9y.mongodb.net/?retryWrites=true&w=majority");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("testDB");
        collection = database.getCollection("testCollection");
    }
    public String handleRequest(String departureAirport, String destinationAirport, String phoneInfo) throws IOException {
        //URL for the 3rd party API
        String url = "https://www.carboninterface.com/api/v1/estimates";
        URL apiUrl = new URL(url);

        try { // setting up connection with the URL
            HttpURLConnection connection = (HttpURLConnection) apiUrl.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer Z0CYCC4OES85j68HAA1A");
            connection.setRequestProperty("Content-Type", "application/json");

            //creating appropriate JSON string to send a request to the 3rd party API
            String passengers = "1";
            String type = "flight";
            String requestBody = "{\"type\": \"" + type +"\",\"passengers\": " + passengers + ",\"legs\": [{\"departure_airport\": \""+ departureAirport + "\", " +
                    "\"destination_airport\": \""+ destinationAirport + "\"}]}";
            connection.setDoOutput(true);
            connection.getOutputStream().write(requestBody.getBytes());
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuilder responseBody = new StringBuilder();
            // reading API's response
            while ((inputLine = in.readLine()) != null) {
                responseBody.append(inputLine);
            }
            in.close();
            //error handling for invalid data received from API
            if (responseBody == null || responseBody.toString().trim().equals("")) {
                System.out.println("Invalid data received from API.");
                return null;
            }
            //calling the function to filter the json data for sending appropriate response to android app
            String filteredJson = getFilteredJson(String.valueOf(responseBody));
            Gson gson = new Gson();

            //updating the JSON to carry information about the device sending the request
            JsonObject jsonObject = gson.fromJson(responseBody.toString(), JsonObject.class);
            JsonObject data = jsonObject.getAsJsonObject("data");
            JsonObject attributes = data.getAsJsonObject("attributes");
            attributes.addProperty("phone", phoneInfo);
            String updatedJsonStr = gson.toJson(jsonObject);

            //send the json data to logger function for logging
            loggerHandler(updatedJsonStr);
            return filteredJson;
        } catch (IOException e) {
            System.out.println("Failed to connect to API server.");
            throw new RuntimeException(e);
        } catch (JsonSyntaxException e) {
            throw new RuntimeException(e);
        }
    }
    /*method to filter the json data received from the 3rd party API and only keep relevant inforamtion
    to be sent to the native android app*/
    private String getFilteredJson(String jsonString) {
        Gson gson = new Gson();
        JSONObject jsonObject = new JSONObject(jsonString);

        // Extract the required fields from the JSONObject
        JSONObject attributes = jsonObject.getJSONObject("data").getJSONObject("attributes");
        String from = attributes.getJSONArray("legs").getJSONObject(0).getString("departure_airport");
        String to = attributes.getJSONArray("legs").getJSONObject(0).getString("destination_airport");
        double distance = attributes.getDouble("distance_value");
        double carbon_kg = attributes.getDouble("carbon_kg");
        System.out.println(from + to+ distance+carbon_kg);

        // Create a new object of ResponseModel class with required fields
        ResponseModel responseModel = new ResponseModel(from , to, distance, carbon_kg);
        String responseModelJsonString = gson.toJson(responseModel);
        return responseModelJsonString;

    }
    //inserts the json string of log information to the mongo collection
    private void loggerHandler(String log) {
        Document bson = Document.parse(log);
        collection.insertOne(bson);
    }
    /*This method retrieves all trip logs from the MongoDB database,
    filters the relevant data from each log, and returns a list of Log objects.*/
    public List<Log> getDashboardLogs() {
        MongoCursor<Document> cursor = collection.find().iterator();
        logs = new ArrayList<>();
        while (cursor.hasNext()) {
            Document docToGet = cursor.next();
            Document data = docToGet.get("data", Document.class);
            if (data != null) {
                Document attributes = data.get("attributes", Document.class);
                ArrayList legs = attributes.get("legs", ArrayList.class);
                Log log = new Log();
                String json = ((Document) legs.get(0)).toJson();
                JsonObject jsonObject = new Gson().fromJson(json, JsonObject.class);
                log.departure_airport = jsonObject.get("departure_airport").getAsString();
                log.destination_airport = jsonObject.get("destination_airport").getAsString();
                log.distance_value = attributes.getDouble("distance_value");
                log.estimated_at = attributes.getString("estimated_at");
                log.carbon_kg = attributes.getDouble("carbon_kg");
                log.carbon_lb = attributes.getDouble("carbon_lb");
                log.phone = attributes.getString("phone");
                logs.add(log);
            }
        }
        return logs;
    }
    /* Method to calculate the Operation Analytics metrics*/
    public List<String> getDashboardAnalytics() {
        List<String> analytics = new ArrayList<>();
        //calculating average carbon emissions by all flights
        double averageCarbonKg = logs.stream()
                .mapToDouble(Log::getCarbon_kg)
                .average().getAsDouble();
        ////calculating total distance of all flights
        double totalDistance = logs.stream()
                .mapToDouble(Log::getDistance_value)
                .sum();
        //calculating longest distance amongst all flights
        double maxDistance = logs.stream()
                .mapToDouble(Log::getDistance_value)
                .max().getAsDouble();
        // Data structure to store the counts of occurrences of all airports to get the highest frequency
        HashMap<String, Integer> airportCounts = new HashMap<>();
        //iterating over all logs to calculate frequncy of each airport
        for (Log log : logs) {
            String departureAirport = log.getDeparture_airport();
            String destinationAirport = log.getDestination_airport();

            // increment departure airport count
            if (airportCounts.containsKey(departureAirport)) {
                airportCounts.put(departureAirport, airportCounts.get(departureAirport) + 1);
            } else {
                airportCounts.put(departureAirport, 1);
            }

            // increment destination airport count
            if (airportCounts.containsKey(destinationAirport)) {
                airportCounts.put(destinationAirport, airportCounts.get(destinationAirport) + 1);
            } else {
                airportCounts.put(destinationAirport, 1);
            }
        }

        // find the most frequent airport
        String mostFrequentAirport = null;
        int highestCount = -1;

        for (String airport : airportCounts.keySet()) {
            int count = airportCounts.get(airport);
            if (count > highestCount) {
                highestCount = count;
                mostFrequentAirport = airport;
            }
        }
        // putting in values and sending operation analytics
        double earth = 40075;
        analytics.add("Average Carbon Emissions: "+String.format("%.2f", averageCarbonKg));
        analytics.add("Most Visited Airport: "+mostFrequentAirport);
        analytics.add("Longest Distance Travelled: "+maxDistance);
        analytics.add("Total Distance Travelled: " + String.format("%.2f", totalDistance) + " (That is "+ (Math.round(totalDistance/earth * 100.0) / 100.0) +
                " times the circumference of earth!)");
        return analytics;
    }
}