package ds.edu.project4androidapp;

/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * Class for structuring of response received from the server.
 */
public class ResponseModel {
    String departure_airport;
    String destination_airport;
    double distance_value;
    double carbon_kg;
}
