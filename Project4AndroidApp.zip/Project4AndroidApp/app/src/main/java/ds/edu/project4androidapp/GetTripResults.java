package ds.edu.project4androidapp;

import android.app.Activity;
import android.os.Build;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 * This class provides capabilities to search for results of carbon emissions given two airports. The method 'hitServer' is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of inner class BackgroundTask that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the MainActivity resultsReady method to do the update.
 *
 * Method BackgroundTask.doInBackground( ) does the background work
 * Method BackgroundTask.onPostExecute( ) is called when the background work is
 * done; it calls *back* to ip to report the results
 */
public class GetTripResults {
    MainActivity ma = null; // for callback
    String resultJson; // returned from server
    String from; // departure airport
    String to; //destination airport

    /*
    hitServer( )
    Parameters:
    String from: departure airport to send to server
    String to: destination airport to send to server
    Activity activity: the UI thread activity
    MainActivity ma: the callback method's class; here, it will be ma.resultsReady( )
     */
    public void hitServer(String from, String to, Activity activity, MainActivity ma) {
        this.from = from;
        this.to = to;
        this.ma = ma;
        new BackgroundTask(activity).execute();
    }
    // class BackgroundTask
    // Implements a background thread for a long running task that should not be
    //    performed on the UI thread. It creates a new Thread object, then calls doInBackground() to
    //    actually do the work. When done, it calls onPostExecute(), which runs
    //    on the UI thread to update some UI widget (***never*** update a UI
    //    widget from some other thread!)
    //
    // Adapted from one of the answers in
    // https://stackoverflow.com/questions/58767733/the-asynctask-api-is-deprecated-in-android-11-what-are-the-alternatives
    // Modified by Barrett
    //
    // Ideally, this class would be abstract and parameterized.
    // The class would be something like:
    //      private abstract class BackgroundTask<InValue, OutValue>
    // with two generic placeholders for the actual input value and output value.
    // In addition, the methods doInBackground() and onPostExecute( ) could be
    //    abstract methods; would need to finesse the input and output values.
    // The call to activity.runOnUiThread( ) is an Android Activity method that
    //    somehow "knows" to use the UI thread, even if it appears to create a
    //    new Runnable.

    public class BackgroundTask {
        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        public void execute() {
            startBackground();
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }
        // doInBackground( ) implements whatever you need to do on
        //    the background thread.
        // Implement this method to suit your needs
        private void doInBackground() {
            resultJson = hitServerURL(from, to);
        }
        /*
         * Send a request to the server with the airport codes, and return a json String that can be put in textViews
         */
        private String hitServerURL(String from, String to) {
            try {
                String phoneInfo = Build.MANUFACTURER + " " + Build.MODEL;
                // Create URL object with the servlet URL
                URL url = new URL("https://dikshachand-humble-orbit-vqr456j95vx2wjj4-8080.preview.app.github.dev/getTripResults?from="+
                        from + "&to=" + to + "&phone=" + phoneInfo);

                // Open connection to the servlet
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                // Get the response from the servlet
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                // Close the connection
                connection.disconnect();

                // Return the response as a string
                return response.toString();

            } catch (Exception e) { //error handling for unsuccessful connection to server
                e.printStackTrace();
            }
            return null;

        }
        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes.
        // Implement this method to suit your needs
        public void onPostExecute() {
            ma.resultsReady(resultJson);
        }
    }
}
