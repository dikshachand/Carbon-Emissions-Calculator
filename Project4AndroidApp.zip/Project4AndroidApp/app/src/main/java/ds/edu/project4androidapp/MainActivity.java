package ds.edu.project4androidapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.google.gson.Gson;

/**
 * @author Diksha Chand (dchand)
 * @version 1.0
 */
public class MainActivity extends AppCompatActivity {
    MainActivity me = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
         * The click listener will need a reference to this object, so that upon successfully getting response from server, it
         * can callback to this object with the resulting json string.  The "this" of the OnClick will be the OnClickListener, not
         * this MainActivity.
         */
        final MainActivity ma = this;
        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = findViewById(R.id.button);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                String from = ((EditText)findViewById(R.id.departureAirport)).getText().toString();
                String to = ((EditText)findViewById(R.id.destinationAirport)).getText().toString();
                if (!isValid(from.trim()) || !isValid(to.trim())) {
                    TextView distanceTextView = findViewById(R.id.textViewDistance);
                    TextView carbonKgTextView = findViewById(R.id.textViewCarbon);
                    distanceTextView.setText(R.string.enterValidInputsString);
                    carbonKgTextView.setText("");
                    return;
                }
                GetTripResults gtr = new GetTripResults();
                gtr.hitServer(from, to, me, ma); // Done asynchronously in another thread. It calls ma.resultsReady() in this thread when complete.
            }
        });
    }

    private boolean isValid(String code) {
        if (code.length() != 3) {
            return false;
        }
        for (int i = 0; i < 3; i++) {
            if (!Character.isLetter(code.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    /*
     * This is called by the GetResults object when the json is ready.  This allows for passing back the json for updating the TextView
     */
    public void resultsReady(String resultJson) {
        TextView distanceTextView = findViewById(R.id.textViewDistance);
        TextView carbonKgTextView = findViewById(R.id.textViewCarbon);
        distanceTextView.setVisibility(View.INVISIBLE);
        carbonKgTextView.setVisibility(View.INVISIBLE);
        if (resultJson != null) { // only if a result is received, update the textViews with the extracted data
            Gson gson = new Gson();
            System.out.println(resultJson);
            ResponseModel rm = gson.fromJson(resultJson, ResponseModel.class);
            System.out.println(rm.departure_airport);
            // Display the values in your UI elements
            distanceTextView.setText("Estimated distance between "+ rm.departure_airport+" and "
            + rm.destination_airport + ": " + rm.distance_value + " km" );
            carbonKgTextView.setText("Estimated carbon emissions: " + rm.carbon_kg
            + " kg");
            distanceTextView.setVisibility(View.VISIBLE);
            carbonKgTextView.setVisibility(View.VISIBLE);
        } else {
            System.out.println("Invalid response data.");
            distanceTextView.setText(R.string.finalErrorString);
        }
    }
}
